"""Enrichment for a pre-defined schema."""

from enrichment_agent.graph import graph

__all__ = ["graph"]
