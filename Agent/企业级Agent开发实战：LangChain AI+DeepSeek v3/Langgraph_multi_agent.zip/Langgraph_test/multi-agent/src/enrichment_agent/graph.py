"""Define a data enrichment agent.

Works with a chat model with tool calling support.
"""

from langgraph.prebuilt import create_react_agent
from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langchain_openai import ChatOpenAI
from enrichment_agent.tools import python_repl, add_sale, delete_sale, update_sale, query_sales
from enrichment_agent.state import AgentState
from typing_extensions import TypedDict
from typing import Literal


# 用于普通问答对话
chat_llm = ChatOpenAI(model="deepseek-chat",
                   api_key='sk-4533d8ff9c0329e',
                   base_url='https://api.deepseek.com')

# 用于数据库检索
db_llm = ChatOpenAI(model="deepseek-chat",
                   api_key='sk-45301cd8dfc0329e',
                   base_url='https://api.deepseek.com')

# 用于代码生成和执行代码
coder_llm = ChatOpenAI(model="deepseek-chat",
                   api_key='sk-4533d8fcd8dfc0329e',
                   base_url='https://api.deepseek.com')


# 创建 模型
db_agent = create_react_agent(
    db_llm,
    tools=[add_sale, delete_sale, update_sale, query_sales],
    state_modifier="You use to perform database operations while should provide accurate data for the code_generator to use"
)

code_agent = create_react_agent(
    db_llm,
    tools=[python_repl],
    state_modifier="Run python code to display diagrams or output execution results"
)

# 创建普通对话问答节点
def chat(state: AgentState):
    messages = state["messages"][-1]
    model_response = chat_llm.invoke(messages.content)
    final_response = [HumanMessage(content=model_response.content, name="chatbot")]
    return {"messages": final_response}

# 创建执行数据库操作节点
def db_node(state: AgentState):
    result = db_agent.invoke(state)
    return {
        "messages": [
            HumanMessage(content=result["messages"][-1].content, name="sqler")
        ]
    }

# 创建代码执行节点
def code_node(state: AgentState):
    result = code_agent.invoke(state)
    return {
        "messages": [HumanMessage(content=result["messages"][-1].content, name="coder")]
    }


# 任何一个代理都可以决定结束

members = ["chat", "coder", "sqler"]
options = members + ["FINISH"]


class Router(TypedDict):
    """Worker to route to next. If no workers needed, route to FINISH"""
    next: Literal[*options]


def supervisor(state: AgentState):
    system_prompt = (
        "You are a supervisor tasked with managing a conversation between the"
        f" following workers: {members}.\n\n"
        "Each worker has a specific role:\n"
        "- chat: Responds directly to user inputs using natural language.\n"
        "- coder: un python code to display diagrams or output execution results.\n"
        "- sqler: perform database operations while should provide accurate data for the code_generator to use.\n"
        " Given the following user request, respond with the worker to act next."
        " Each worker will perform a task and respond with their results and status."
        "When you think the result has answered the user's question, just reply FINISH."
    )

    messages = [{"role": "system", "content": system_prompt},] + state["messages"]

    response = db_llm.with_structured_output(Router).invoke(messages)
    next_ = response["next"]
    if next_ == "FINISH":
        next_ = END
    return {"next": next_}


workflow = StateGraph(AgentState)

workflow.add_node("supervisor", supervisor)
workflow.add_node("chat", chat)
workflow.add_node("coder", code_node)
workflow.add_node("sqler", db_node)

for member in members:
    # 每个子代理在完成工作后总是向主管“汇报”
    workflow.add_edge(member, "supervisor")

workflow.add_edge(START, "supervisor")
# 在图状态中填充`next`字段，路由到具体的某个节点或者结束图的运行，从来指定如何执行接下来的任务。
workflow.add_conditional_edges("supervisor", lambda state: state["next"])

# 编译图
graph = workflow.compile()

graph.name = "multi-Agent"

